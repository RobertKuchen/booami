#' @keywords internal
#' @importFrom utils modifyList
#' @importFrom stats na.omit plogis
NULL